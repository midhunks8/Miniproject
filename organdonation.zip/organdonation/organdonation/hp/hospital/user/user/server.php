<?php 
session_start();

$username = "";
$email	  = "";
$errors   = array();

$db = mysqli_connect('localhost', 'root', '', 'donation');


if (isset($_POST['reg_user'])) {

	$username   = mysqli_real_escape_string($db, $_POST['username']);
	$email	    = mysqli_real_escape_string($db, $_POST['email']);
	$age = mysqli_real_escape_string($db, $_POST['age']);
	$district = mysqli_real_escape_string($db, $_POST['district']);
	$bloodgroup = mysqli_real_escape_string($db, $_POST['bloodgroup']);

	// checking filled
	if (empty($username)) { 
		array_push($errors, "** Username is required");
	}
	if (!preg_match ("/^[a-zA-z]*$/", $username) ) {  
		array_push($errors,  "** Only alphabets and whitespace are allowed.");  
	}
	if (empty($email)) {
		array_push($errors, "** Street is required");
	}
	if (empty($district)) {
		array_push($errors, "** city is required");
	}

	if (empty($age)) {
		array_push($errors, "** age is required");
	}
	if (empty($bloodgroup)) {
		array_push($errors, "** blood group is required");
	}

	//if (empty($password_1)) {
		//array_push($errors, "** Password is required");
	//}
	


	$user_check_query = "SELECT id FROM users WHERE username='$username'";
	$result = mysqli_query($db, $user_check_query);
	//$user = mysqli_fetch_assoc($result);
	if(mysqli_num_rows($result)>0)   {
		while($row = mysqli_fetch_assoc($result)) {
		
			$val = $row['id'];
		}
	}


	echo "Total error: " . count($errors);

	// Insert New Data
	if (count($errors) == 0) {

		$query = "INSERT INTO `donor_personaldet`(`id`, `username`, `street`, `district`, `age`, `bloodgroup`) VALUES  ('$val','$username', '$email', '$district', '$age', '$bloodgroup')";
		mysqli_query($db, $query);
		header('location: ../dashboard.php');
		echo '<script>alert("success")</script>';
		
	}

}

// Click Login
if (isset($_POST['login_user'])) {
	$username = mysqli_real_escape_string($db, $_POST['username']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	if (empty($username)) {
		array_push($errors, "Username is required");
	}

	if (empty($password)) {
		array_push($errors, "Password is required");
	}

	if (count($errors) == 0) {
		$password = md5($password);

		$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
		$results = mysqli_query($db, $query);
		if (mysqli_num_rows($results) == 1) {
			$_SESSION['username'] = $username;
			$_SESSION['success']  = "You are now logged in";
			header('location: index.php');
		} else {
			array_push($errors, "Wrong username/password combination");
		}
	}
}

?>