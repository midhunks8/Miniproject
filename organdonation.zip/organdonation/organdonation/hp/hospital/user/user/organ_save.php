<?php 
session_start();

$username = "";
$email	  = "";
$errors   = array();

$db = mysqli_connect('localhost', 'root', '', 'blood_donation');


if (isset($_POST['reg_user'])) {

	$username   = mysqli_real_escape_string($db, $_POST['username']);
	$age = mysqli_real_escape_string($db, $_POST['age']);
	$bloodgroup = mysqli_real_escape_string($db, $_POST['bloodgroup']);
    $donate = $_POST["Donate"];

	// checking filled
	if (empty($username)) { 
		array_push($errors, "** Username is required");
	}
	if (!preg_match ("/^[a-zA-z]*$/", $username) ) {  
		array_push($errors,  "** Only alphabets and whitespace are allowed.");  
	}

	if (empty($age)) {
		array_push($errors, "** age is required");
	}
	if (empty($bloodgroup)) {
		array_push($errors, "** blood group is required");
	}
	


	$user_check_query = "SELECT id FROM users WHERE username='$username'";
	$result = mysqli_query($db, $user_check_query);
	//$user = mysqli_fetch_assoc($result);
	if(mysqli_num_rows($result)>0)   {
		while($row = mysqli_fetch_assoc($result)) {
		
			$val = $row['id'];
		}
	}


	echo "Total error: " . count($errors);

	// Insert New Data
	if (count($errors) == 0) {

		$cont = sizeof($donate);
        for($i =0; $i<$cont; $i++)
		{
			$query="INSERT INTO `organ_details`(`uid`, `username`, `age`, `bloodgroup`, `organ`) VALUES ('$val','$username', '$age', '$bloodgroup','$donate[$i]')"; 
            mysqli_query($db, $query);
			
			
        }
       
		echo"<script type='text/javascript'>window.alert('successfully completed');window.location='org_det.php';</script>";
    
		
	}

}

?>