<?php
$conn=mysqli_connect("localhost", "root", "", "donation");
if (!$conn) {
    die("Database Connect Error");
}
$name=$_POST['hospitalName'];
$address=$_POST['Hospitaladd'];
$phno=$_POST['phonenum'];
$pass=$_POST['pass'];
$rpass=$_POST['apass'];

if ($pass==$rpass) {
    $sql="INSERT INTO `hospital`(`name`, `add`, `phno`, `pass`) VALUES ('$name','$address','$phno','$pass')";
    $re=mysqli_query($conn, $sql);
   
        echo"<script type='text/javascript'>window.alert('successfully completed');window.location='login.php';</script>";
   
}
 else {
    echo"<script type='text/javascript'>window.alert('Password Does Not Match,Please Try Again');window.location='signdo.html';</script>";
}

mysqli_close($conn);
?>



