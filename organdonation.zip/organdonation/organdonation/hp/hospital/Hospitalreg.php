<html>
  <head>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Hospitals</title>
   
    <style>
      .aa {
        width: 450px;
        height: 550px;
      }
    </style>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
  
  </head>

  <body>
    
    <div id="nav-placeholder"></div>

    <div class="aa" style="background-color: rgba(0, 0, 0, 0.5)">
      <form method="post" action="reghos.php">
        <h1 style="color: skyblue">Sign Up</h1>
        <input
          type="text"
          name="hospitalName"
          placeholder="Please Enter Hopital name...."
        /><br /><br />
        <input
          type="text"
          name="Hospitaladd"
          placeholder="Please Enter Hopital Address...."
        /><br /><br />
        <input
          type="text"
          name="phonenum"
          placeholder="Please Enter Phone Number...."
        /><br /><br />

        <input
          type="password"
          name="pass"
          placeholder="Please Enter Password...."
        /><br /><br />
        <input
          type="password"
          name="apass"
          placeholder="Please Enter Password Once more...."
        /><br /><br />
        <input
          type="submit"
          value="Sign Up"
          name="submit"
          class="btn_login"
          style="background-color: skyblue"
        />
        <p style="font-size: 18px">
          Already User then,Click <a href="login.php">here</a> to Log
          in.
        </p>
      </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  </body>
</html>

