<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Personal Details</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Register</h2>
	</div>

	<form method="post" action="register.php">
		<?php include('errors.php') ?>
		<div class="input-group">
			<label>Patient name <span style="color:red">*</span></label>
			<input type="text" name="username" value="<?php echo $username; ?>" required>
		</div>
		<div class="input-group">
			<label>Disease<span style="color:red">*</span></label>
			<input type="text" name="email" value="<?php echo $email; ?>" required>
		</div>
		<!--<div class="input-group">
			<label>City <span style="color:red">*</span></label>
			<input type="text" name="city" value="<?php echo $city; ?>" >
		</div>-->
		<div class="input-group">
			<label>Organ Needed<span style="color:red">*</span></label>
			<select name="district" style="width: 400px; height: 40px;" required>
			<option value="">Select Your District</option>
			<option value="Kidney">Kidney</option>
			<option value="Heart">Heart</option>
			<option value="Liver">Liver</option>
			<option value="Corneas">Corneas</option>
			<option value="Lungs">Lungs</option>
			<option value="Pancreas">Pancreas</option>
			<option value="Tissue">Tissue</option>
			

			</select>
		</div>
		<div class="input-group">
			<label>Age <span style="color:red">*</span></label>
			<select name="age" style="width: 400px; height: 40px;" required>
			<option value="">Select Your  age</option>
		
			<?php
    			for ($i=18; $i<=50; $i++)
    			{
        	?>
            <option value="<?php echo $i;?>"><?php echo $i;?></option>
        	<?php
    		}
			?>

			</select>
		</div>
		<div class="input-group">
			<label>Blood Group <span style="color:red">*</span></label>
			<select name="bloodgroup" style="width: 400px; height: 40px;" required>
			<option value="">Select Your Blood Group</option>
			<option value="a+">A+</option>
			<option value="b+">B+</option>
			<option value="ab+">AB+</option>
			<option value="o+">O+</option>
			<option value="a-">A-</option>
			<option value="b-">B-</option>
			<option value="ab-">AB-</option>
			<option value="o-">O-</option>
			</select>
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="reg_user">Register</button>
		</div>
		<p>
			Update Your personal details <a href="login.php">Update</a>
		</p>
	</form>
</body>
</html>