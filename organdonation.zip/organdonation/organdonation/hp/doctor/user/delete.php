<?php
include 'conn.php';
  $donor_id = $_GET['id'];
$sql= "DELETE FROM patient_details where id={$donor_id}";
$result=mysqli_query($conn,$sql);

header("Location: donor_list.php");

mysqli_close($conn);

 ?>
