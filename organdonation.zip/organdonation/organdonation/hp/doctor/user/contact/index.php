<html>
<head>
    <title>Contact Details of Donor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<style>
      .container {
        max-width: 500px;
        margin: auto;
    }
      
    </style>
<body>
    <div class="container">
        <h3 >Contact Details of Donor</h3><br>
        <form action="form-process.php" method="POST">
            <div class="form-group">
                <label for="firstname">Username</label>
                <input type="text" name="firstname" id="firstname" class="form-control" style="width: 400px;" required>
            </div>
            <div class="form-group">
                <label for="lastname">Place</label>
                <input type="text" name="lastname" id="lastname" class="form-control" style="width: 400px;" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="tel" name="phone" id="phone" class="form-control" style="width: 400px;" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" style="width: 400px;"required>
            </div>
            <div class="form-group">
                <label for="message">Emergency Contact Number</label>
                <input type="text" name="message" id="message" class="form-control" style="width: 400px;" required>
            </div>
            <div class="form-group">
        <button class="btn btn-danger" type="reset">Reset</button>
        <button class="btn btn-success" type="submit">Submit</button>
        <button class="btn btn-danger" type="reset">Update</button>
    </div>
        </form>
    </div>
</body>

</html>