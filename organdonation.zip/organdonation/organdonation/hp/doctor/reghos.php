<?php
include 'conn.php';
$name=$_POST['hospitalName'];
$address=$_POST['Hospitaladd'];
$phno=$_POST['phonenum'];
$pass=$_POST['pass'];
$rpass=$_POST['apass'];

if ($pass==$rpass) {
    $sql="INSERT INTO `hospital`(`name`, `add`, `phno`, `pass`) VALUES ('$name','$address','$phno','$pass')";
  $rr=mysqli_query($conn, $sql);
    if ($rr) {
        echo"<script type='text/javascript'>window.alert('successfully completed');window.location='signdo.html';</script>";
    } 
}
 else {
    echo"<script type='text/javascript'>window.alert('Password Does Not Match,Please Try Again');window.location='signdo.html';</script>";
}

mysqli_close($conn);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>



