<?php
$conn=mysqli_connect("localhost", "root", "", "donation");
if (!$conn) {
    die("Database Connect Error");
}
session_start();

if (isset($_POST['uname'])) {
    $uname=$_POST['uname'];
    $password=$_POST['pass'];



    $sql="select * from hospital where name='".$uname."'AND pass='".$password."'limit 1";

    $result=$conn->query($sql);

    if ($result->num_rows==1) {
        $_SESSION["name"] = $uname;
        echo"<script type='text/javascript'>window.alert('Login successfull');window.location='index.php';</script>";
    } else {
        echo"<script type='text/javascript'>window.alert('Invalid Username or Password');window.location='../index.html';</script>";
    }
}
?>





