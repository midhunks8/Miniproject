<?php
$conn=mysqli_connect("localhost", "root", "", "donation");
if (!$conn) {
    die("Database Connect Error");
}
$name=$_POST['name'];
$mail=$_POST['mail'];
$address=$_POST['address'];
$phno=$_POST['phno'];
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$rpass=$_POST['repass'];

if ($pass==$rpass) {
    $sql="INSERT INTO `doctors`(`name`, `mail`, `address`, `phno`, `department`, `uname`, `pass`) VALUES('$name','$mail','$address','$phno','organ','$uname','$pass')";

    if (mysqli_query($conn, $sql)) {
        echo"<script type='text/javascript'>window.alert('successfully completed');window.location='signdo.html';</script>";
    } 
}
 else {
    echo"<script type='text/javascript'>window.alert('Password Does Not Match,Please Try Again');window.location='signdo.html';</script>";
}

mysqli_close($conn);
?>



