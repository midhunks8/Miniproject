<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'donation';

$conn = mysqli_connect($host, $user, $pass, $db);
?>