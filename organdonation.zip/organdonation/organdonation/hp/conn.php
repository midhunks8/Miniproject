<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'organ_donation';

$conn = mysqli_connect($host, $user, $pass, $db);
?>