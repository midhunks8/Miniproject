<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Personal Details</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Register</h2>
	</div>

	<form method="post" action="register.php">
		<?php include('errors.php') ?>
		<div class="input-group">
			<label>Username <span style="color:red">*</span></label>
			<input type="text" name="username" value="<?php echo $username; ?>" required>
		</div>
		<div class="input-group">
			<label>Street <span style="color:red">*</span></label>
			<input type="text" name="email" value="<?php echo $email; ?>" required>
		</div>
		<!--<div class="input-group">
			<label>City <span style="color:red">*</span></label>
			<input type="text" name="city" value="<?php echo $city; ?>" >
		</div>-->
		<div class="input-group">
			<label>District <span style="color:red">*</span></label>
			<select name="district" style="width: 400px; height: 40px;" required>
			<option value="">Select Your District</option>
			<option value="Thiruvananthapuram">Thiruvananthapuram</option>
			<option value="Kollam">Kollam</option>
			<option value="Pathanamthitta">Pathanamthitta</option>
			<option value="Idukki">Idukki</option>
			<option value="Alappuzha">Alappuzha</option>
			<option value="Ernakulam">Ernakulam</option>
			<option value="Thrissur">Thrissur</option>
			<option value="Palakkad">Palakkad</option>
			<option value="Malappuram">Malappuram</option>
			<option value="Kozhikode">Kozhikode</option>
			<option value="Wayanad">Wayanad</option>
			<option value="Kannur">Kannur</option>
			<option value="Kasarkode">Kasarkode</option>

			</select>
		</div>
		<div class="input-group">
			<label>Age <span style="color:red">*</span></label>
			<select name="age" style="width: 400px; height: 40px;" required>
			<option value="">Select Your  age</option>
		
			<?php
    			for ($i=1; $i<=50; $i++)
    			{
        	?>
            <option value="<?php echo $i;?>"><?php echo $i;?></option>
        	<?php
    		}
			?>

			</select>
		</div>
		<div class="input-group">
			<label>Blood Group <span style="color:red">*</span></label>
			<select name="bloodgroup" style="width: 400px; height: 40px;" required>
			<option value="">Select Your Blood Group</option>
			<option value="a+">A+</option>
			<option value="b+">B+</option>
			<option value="ab+">AB+</option>
			<option value="o+">O+</option>
			<option value="a-">A-</option>
			<option value="b-">B-</option>
			<option value="ab-">AB-</option>
			<option value="o-">O-</option>
			</select>
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="reg_user">Register</button>
		</div>
		
	</form>
</body>
</html>