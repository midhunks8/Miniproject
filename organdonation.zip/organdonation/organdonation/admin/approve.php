<?php
include 'conn.php';
$aa_id=$_GET['id'];
$ss=$_GET['sts'];
if($ss == 1){
    mysqli_query($conn,"UPDATE `admin_contact` SET query_status = 1 WHERE id='$aa_id'");
    echo"<script>alert('successfully accepted');</script>";


}

header('location:query.php')
?>
<!-- include 'db.php';
$aa_id=$_GET['a_id'];
$ss=$_GET['ss'];
if($ss == 1){
    $ap = "UPDATE `login_tb` SET status=1 WHERE Lg_id = '$aa_id'";
    mysqli_query($conn,$ap);
    // echo "<script>alert('successfully approved user');</script>";
} -->