<?php
include 'conn.php';

$que_id = $_GET['id'];
$sql= "DELETE FROM admin_contact where id={$que_id}";
$result=mysqli_query($conn,$sql);
mysqli_close($conn);

 ?>
