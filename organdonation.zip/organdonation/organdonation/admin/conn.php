<?php
$conn=mysqli_connect("localhost","root","","donation") or die("Connection error");
?>
