<?php
include 'conn.php';
  $donor_id = $_GET['id'];
$sql= "DELETE FROM donor_personaldet where id={$donor_id}";
$result=mysqli_query($conn,$sql);

header("Location: donor_list.php");

mysqli_close($conn);
echo '<div class="alert alert-success alert_dismissible"><b><button type="button" class="close" data-dismiss="alert">&times;</button></b><b>Query Sent, We will contact you shortly. </b></div>';

 ?>
